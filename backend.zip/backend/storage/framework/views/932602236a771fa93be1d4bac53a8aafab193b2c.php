<?php echo e($slot); ?>

<?php /**PATH C:\Users\THEO\Documents\TCC\projeto-tcc-AM\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>