<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\THEO\Documents\TCC\projeto-tcc-AM\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>